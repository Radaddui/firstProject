package org.zerock.myapp.domain;

public enum Role {
    ROLE_ADMIN,
    ROLE_USER

} // end Enum
