package org.zerock.myapp.domain;

public enum ReportStatus {
    REPORT_NOTRECEIVED,
    REPORT_RECEIVED,
    REPORT_CONFIRM,
    REPORT_PROCESSING

} // end Enum
