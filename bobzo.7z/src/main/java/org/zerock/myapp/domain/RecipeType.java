package org.zerock.myapp.domain;

public enum RecipeType {
    KoreanFood,
    ChineseFood,
    JapanFood,
    WesternFood

} // End Enum
