package org.zerock.myapp.service;

import org.zerock.myapp.domain.Users;
import org.zerock.myapp.domain.UsersDTO;

public interface MypageService {

    public abstract void updateInfo(UsersDTO usersDTO);



} // end interface
